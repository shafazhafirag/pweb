import React from "react";
import { Col, Row } from "react-bootstrap";
import { CgCPlusPlus } from "react-icons/cg";
import {
  //import gambar pada module sesuai keahlian kalian dibidang apa
} from "react-icons/di";

function Edu() {
  return (
    <Row style={{ justifyContent: "center", paddingBottom: "50px" }}>
      <Col xs={4} md={2} className="tech-icons">
        <CgCPlusPlus />
      </Col>
      
      
      
    </Row>
  );
}

export default Edu;
